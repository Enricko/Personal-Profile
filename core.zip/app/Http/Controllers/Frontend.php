<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Portfolio;
use App\Models\pengalaman;
use App\Models\service;
use App\Models\carousel;
use App\Models\about;
use App\Models\skill;
use App\Models\Personal_info;
use App\Models\program;

class Frontend extends Controller
{
    public function __construct()
    {
        $this->portfolio = new Portfolio();
        $this->pengalaman = new Pengalaman();
        $this->service = new service();
        $this->carousel = new carousel();
        $this->about = new about();
        $this->skill = new skill();
        $this->personal_info = new Personal_info();
        $this->program = new program();
    }
    public function index(){
        $data['port'] = $this->portfolio->allData();
        $data['pengalaman_6'] = $this->pengalaman->data_6();
        $data['service_4'] = $this->service->data_4();
        $data['carousel_5'] = $this->carousel->data_5();
        $data['about'] = $this->about->data_1();
        $data['skill'] = $this->skill->data_5();
        $data['personal_info'] = $this->personal_info->allData();
        return view('frontend.index',$data);
    }
    public function cv(){
        $data['port'] = $this->portfolio->allData();
        $data['pengalaman'] = $this->pengalaman->allData();
        $data['service'] = $this->service->allData();
        $data['carousel'] = $this->carousel->allData();
        $data['about'] = $this->about->allData();
        $data['skill'] = $this->skill->allData();
        $data['personal_info'] = $this->personal_info->allData();
        $data['program'] = $this->program->allData();
        return view('frontend.cv',$data);
    }
}
