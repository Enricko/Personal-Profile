<section class="w3l-feature-8">
    <div class="container py-md-5 py-4">
        <div class="style-title text-center position-relative mb-3">
            <h1 class="title-style">Service
            </h1>
            <p class="text-para">Melayani segala service yang tersedia
            </p>
        </div>
        <div class="row features text-center py-lg-5">
            <?php $__currentLoopData = $service_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-sm-6 feature-1">
                <div class="feature-body">
                    <div class="feature-images pb-sm-3 pb-1">
                        <img src="<?php echo e(asset('image')); ?>/service/<?php echo e($row->image); ?>" alt="" class="img-fluid">
                    </div>
                    <div class="feature-info mt-3">
                        <a href="about.html">
                            <h3 class="feature-titel">
                                <?php echo e($row->title); ?>

                            </h3>
                        </a>
                        <p class="feature-text"><?php echo e($row->description); ?></p>
                        
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <hr id="blog">
</section><?php /**PATH C:\xampp\htdocs\profile-laravel\resources\views/include/frontend/service.blade.php ENDPATH**/ ?>