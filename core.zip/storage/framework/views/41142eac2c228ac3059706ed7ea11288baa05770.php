
<?php $__env->startSection('title','frontend'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.frontend.app_front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\profile-laravel\resources\views/frontend/index.blade.php ENDPATH**/ ?>