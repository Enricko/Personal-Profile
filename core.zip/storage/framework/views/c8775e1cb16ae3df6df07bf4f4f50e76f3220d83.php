<section class="w3l-aboutblock py-5">
    <div class="container py-md-5 py-sm-4">
        <div class="row">
            <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 left-wthree-img mb-lg-0 mb-md-5 mb-4">
                <img class="img-fluid img-responsive" src="<?php echo e(asset('image')); ?>/about/<?php echo e($row->image); ?>" alt=" ">
            </div>
            <div class="col-lg-6 about-right-faq align-self position-relative pl-lg-5">
                <h3 class="title-style mb-2 pl-4"><?php echo e($row->nama); ?>

                </h3>
                <p class="mt-3 pl-4"><?php echo e($row->description); ?></p>
                <a class="btn btn-style mt-4 ml-4" href="/cv" target="_blank">View CV</a>
                <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h4 class="title-style mb-2 mt-4"><?php echo e($row->skill); ?><span class="float-right"><?php echo e($row->persentage.'%'); ?></span></h4>
                    <?php if($row->persentage >= 80): ?>
                        <div class="progress">
                            <div class="progress-bar progress-bar-animated bg-success" role="progressbar"
                            aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                            <?php echo e($row->persentage.'%'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($row->persentage >= 60 && $row->persentage <= 79): ?>
                        <div class="progress">
                            <div class="progress-bar progress-bar-animated bg-info" role="progressbar"
                            aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                            <?php echo e($row->persentage.'%'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($row->persentage >= 40 && $row->persentage <= 59): ?>
                        <div class="progress">
                            <div class="progress-bar progress-bar-animated bg-primary" role="progressbar"
                            aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                            <?php echo e($row->persentage.'%'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($row->persentage >= 20 && $row->persentage <= 39): ?>
                        <div class="progress">
                            <div class="progress-bar progress-bar-animated bg-warning" role="progressbar"
                            aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                            <?php echo e($row->persentage.'%'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($row->persentage >= 0 && $row->persentage <= 19): ?>
                        <div class="progress">
                            <div class="progress-bar progress-bar-animated bg-danger" role="progressbar"
                            aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                            <?php echo e($row->persentage.'%'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\profile-laravel\resources\views/include/frontend/about.blade.php ENDPATH**/ ?>