<section class="w3l-features">
    <div class="container py-lg-5 py-4">
        <div class="style-title text-center position-relative mb-5">
            <h1 class="title-style">Portfolio
            </h1>
            <p class="text-para">Semua hasil yang telah ku buat selama menjadi fullstack web devoloper.
            </p>
        </div>
        <div class="row">
            <div class="container text-center">
                <?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#popup<?php echo e($row->id); ?>">
                        <img src="<?php echo e(asset('image')); ?>/portfolio/<?php echo e($row->image); ?>" class="portfolio" alt=""/>
                    </a>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="popup<?php echo e($row->id); ?>" class="overlay">
                <div class="popup scroll-port" style="margin-top:100px;">
                    <a href="//<?php echo e($row->link); ?>">
                        <img src="<?php echo e(asset('image')); ?>/portfolio/<?php echo e($row->image); ?>" alt="Popup Image" class="img-fluid" style="width:500px;background-size:cover; background-position: center center;border-radius:5px;"/>
                    </a>
                    <div class="text-center">
                        <h5 class="title-port mt-5"><?php echo e($row->title); ?></h5>
                        <p class="mt-4 mb-4"><?php echo e($row->description); ?></p>
                    </div>
                    <div class="info">
                        <h6 class="info-title-port">MADE IN  </h6>
                        <h6 class="info-subtitle-port"><?php echo e($row->year); ?></h6>
                    </div>
                    <div class="info">
                        <h6 class="info-title-port">INSTITUTION  </h6>
                        <h6 class="info-subtitle-port"><?php echo e($row->institution); ?> </h6>
                    </div>
                    <div class="info">
                        <h6 class="info-title-port" >PROJECT URL  </h6>
                        <a class="info-subtitle-port" href="//<?php echo e($row->link); ?>"><?php echo e($row->link); ?> </a>
                    </div>
                    <a class="close" href="#portfolio">&times;</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\profile-laravel\resources\views/include/frontend/portfolio.blade.php ENDPATH**/ ?>