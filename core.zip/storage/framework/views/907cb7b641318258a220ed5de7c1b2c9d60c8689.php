<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My CV</title>
    <link href="//fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css2?family=Halant:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/style-starter.css">
</head>
<body>
    <div class="d-flex justify-content-center no-print" style="background-color:white;z-index:10;">
        <h5 style="color:red;">Bila gambar / background tidak muncul, ceklis background graphics (more options >> Background Graphics)&nbsp;
        <a href="" class="btn btn-style" onclick="window.print()">Cetak</a></h5>
    </div>
    <div style="background-color:cyan;height:300px;">
        <div class="container d-flex justify-content-between align-items-center">
            <h1 class="mt-3" style="color:white;font-size:45px;font-weight:700;letter-spacing: 2px;line-height:1.1;">Enricko Putra Hartono</h1>
            <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-5">    
                    <img class="img-fluid img-responsive" src="<?php echo e(asset('image')); ?>/about/<?php echo e($row->image); ?>" alt=" " style="width:200px;border-radius:1000px;">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div style="background-color:rgb(233, 233, 233);height:23px;"></div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-5 col-sm-12 mt-3">
                <?php $__currentLoopData = $personal_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="title-style">Personal Info</h5>
                <p class="mt-1" style="font-weight:700;">Name</p>
                <p><?php echo e($row->nama); ?></p>
                <p class="mt-1" style="font-weight:700;">Email</p>
                <p><?php echo e($row->email); ?></p>
                <p class="mt-1" style="font-weight:700;">Nationality</p>
                <p><?php echo e($row->nationality); ?></p>
                <p class="mt-1" style="font-weight:700;">Gender</p>
                <p><?php echo e($row->gender); ?></p>
                <p class="mt-1" style="font-weight:700;">Current Job</p>
                <p><?php echo e($row->current_job); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <h5 class="title-style mt-4">Skills</h5>
                <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-10">
                        <p class="mb-1 mt-1"><?php echo e($row->skill); ?><span class="float-right"><?php echo e($row->persentage.'%'); ?></span></h4>
                        <?php if($row->persentage >= 80): ?>
                            <div class="progress">
                                <div class="progress-bar progress-bar-animated bg-success" role="progressbar"
                                aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                                <?php echo e($row->persentage.'%'); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($row->persentage >= 60 && $row->persentage <= 79): ?>
                            <div class="progress">
                                <div class="progress-bar progress-bar-animated bg-info" role="progressbar"
                                aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                                <?php echo e($row->persentage.'%'); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($row->persentage >= 40 && $row->persentage <= 59): ?>
                            <div class="progress">
                                <div class="progress-bar progress-bar-animated bg-primary" role="progressbar"
                                aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                                <?php echo e($row->persentage.'%'); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($row->persentage >= 20 && $row->persentage <= 39): ?>
                            <div class="progress">
                                <div class="progress-bar progress-bar-animated bg-warning" role="progressbar"
                                aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                                <?php echo e($row->persentage.'%'); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($row->persentage >= 0 && $row->persentage <= 19): ?>
                            <div class="progress">
                                <div class="progress-bar progress-bar-animated bg-danger" role="progressbar"
                                aria-valuenow="<?php echo e($row->persentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($row->persentage.'%'); ?>">
                                <?php echo e($row->persentage.'%'); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="mt-1" style="font-weight:700;">Operating System</p>
                <p><?php echo e($row->operating_system); ?></p>
                <p class="mt-1" style="font-weight:700;">Database</p>
                <p><?php echo e($row->database); ?></p>
                <p class="mt-1" style="font-weight:700;">Framework</p>
                <p><?php echo e($row->framework); ?></p>
                <p class="mt-1" style="font-weight:700;">IDE</p>
                <p><?php echo e($row->ide); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-7 col-sm-12 mt-3">
                <h5 class="title-style">Education And Experience</h5>
                <?php $__currentLoopData = $pengalaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class="title-style"><?php echo e($row->title); ?> --
                <span class="title-style"><?php echo e($row->start_year.' - '.$row->end_year); ?></span></h2>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h5 class="title-style mt-5">Project</h5>
                <?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="info">
                        <h6 class="info-title">YEAR</h6>
                        <h6 class="info-subtitle"><?php echo e($row->year); ?></h6>
                    </div>
                    <div class="info">
                        <h6 class="info-title">PROJECT</h6>
                        <h6 class="info-subtitle"><?php echo e($row->title); ?></h6>
                    </div>
                    <div class="info">
                        <h6 class="info-title">INSTITUTION</h6>
                        <h6 class="info-subtitle"><?php echo e($row->institution); ?></h6>
                    </div>
                    <div class="info">
                        <h6 class="info-title">PROJECT URL</h6>
                        <h6 class="info-subtitle"><a href="//<?php echo e($row->link); ?>/" target="_blank" style="text-decoration:none;"><?php echo e($row->link); ?></a></h6>
                    </div>
                    <hr class="divider-cv">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\profile-laravel\resources\views/frontend/cv.blade.php ENDPATH**/ ?>