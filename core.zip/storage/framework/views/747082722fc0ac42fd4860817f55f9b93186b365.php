
<?php $__env->startSection('title','table'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tables Portfolio</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Portfolio
                <a href="/admin/portfolio/tambah_portfolio" class="btn btn-primary float-right">Tambah Data</a>
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Create at</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?=$no++?></td>
                            <td><img src="<?php echo e(asset('image/portfolio/'.$row->image)); ?>" alt="" style="width:150px"></td>
                            <td><?php echo e($row->title); ?></td>
                            <td><?php echo e($row->description); ?></td>
                            <td><?php echo e($row->created_at); ?></td>
                            <td>
                                <a class="btn btn-warning" href="/admin/portfolio/edit_portfolio/<?php echo e($row->id); ?>">Edit</a>
                                <a class="btn btn-danger" href="/admin/portfolio/delete_portfolio/<?php echo e($row->id); ?>" onclick="return confirm('Apakah anda yakin?')">Delete</a>
                            </td>
                        <tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.admin.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\profile-laravel\resources\views/admin/portfolio.blade.php ENDPATH**/ ?>