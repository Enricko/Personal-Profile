@extends('include.frontend.app_front')
@section('title','frontend')
@section('content')

@endsection